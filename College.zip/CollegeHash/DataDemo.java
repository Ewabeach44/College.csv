public class DataDemo {
    FileParser parser;
    String [] headers;
    public DataDemo (String filename) {
        parser = new FileParser (filename);
    }

    public String [] getHeaders () {
        return parser.getHeaders();
    }

    public String [] getNextLine () {
        return parser.parseNextLine();
    }
    
    public void showDataFor (String college) {
        System.out.println("TO DO! show "+college);
    }
    
    void loadAll () {
        String [] fields = getNextLine();
        while (fields != null) {
            College c = College.fromFields(fields);
            System.out.println(c);
            fields = getNextLine();
        }
        System.out.println("TO DO: load instead of dump!");
    }
    
    public static void main (String [] args) {
        String example = "College.csv";
        DataDemo demo = new DataDemo(example);
        demo.loadAll();        
        demo.showDataFor("Shepherd University");
        demo.showDataFor("West Liberty State College");
    }
}